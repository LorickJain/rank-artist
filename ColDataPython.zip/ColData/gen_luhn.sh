#!/bin/bash

sumy luhn --length=10% --file tmp_files/formatted_file > luhn_sum 
