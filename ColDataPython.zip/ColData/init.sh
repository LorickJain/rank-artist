#!/bin/bash

rm tmp_files/*
chmod +x gen_luhn.sh text_sum.sh compute_score_luhn.py compute_score_text_sum.py
