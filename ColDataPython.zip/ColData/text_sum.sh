#!/bin/bash

sumy text-rank --length=10% --file tmp_files/formatted_file > text_sum 